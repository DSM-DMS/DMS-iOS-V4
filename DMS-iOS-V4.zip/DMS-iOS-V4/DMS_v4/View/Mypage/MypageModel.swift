//
//  MypageModel.swift
//  DMS_v4
//
//  Created by leedonggi on 2020/06/18.
//  Copyright © 2020 leedonggi. All rights reserved.
//

import Foundation

struct MypageModel: Codable{
    let classAndName: String
    let goodAndBad: String
    let extension11: String
    let extension12: String
    let stay: String
}
