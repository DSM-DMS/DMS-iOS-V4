//
//  APIProtocol.swift
//  DMS_SwiftUI
//
//  Created by leedonggi on 2020/03/10.
//  Copyright © 2020 leedonggi. All rights reserved.
//

import Foundation

protocol API {
    
    func getPath() -> String
    
}
